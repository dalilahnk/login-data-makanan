package com.example.login_produk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
